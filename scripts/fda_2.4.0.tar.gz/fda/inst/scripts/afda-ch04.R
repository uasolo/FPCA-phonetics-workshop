###
###
### Ramsey & Silverman (2002) Applied Functional Data Analysis (Springer)
###
### ch. 4.  Bone shapes and arthritis 
###

# data not available 
